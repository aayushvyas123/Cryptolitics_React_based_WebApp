const firebaseConfig = {
    apiKey: process.env.REACT_APP_API_KEY,
    authDomain: "cryptolitics-a259c.firebaseapp.com",
    projectId: "cryptolitics-a259c",
    storageBucket: "cryptolitics-a259c.appspot.com",
    messagingSenderId: "85066093103",
    appId: "1:85066093103:web:f41376018daafb1aea6cda"
  };

  export default firebaseConfig;