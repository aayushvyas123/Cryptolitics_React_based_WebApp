Live Web Application :- https://cryptolitics.netlify.app/

Project Description :-

Cryptolitics is the online Cryptocurrency Statistics tool where you can view, analyze and add cryptocurrencies to your watchlist. In cryptolitics you can also see Cryptocurrencies marketcap, volume, 24 hr high & low with their price charts.

Languages & Tools used :-
Programming Languages :- HTML, CSS , Javascript.
Technology:- React Js.
API:- Coingecko

My LinkedIn profile:- https://www.linkedin.com/in/yash-tiwari-7113b5215/

If you find any bug, errors or any problem please report it to me on Linkedin or you can email me at official.yasht@gmail.com
